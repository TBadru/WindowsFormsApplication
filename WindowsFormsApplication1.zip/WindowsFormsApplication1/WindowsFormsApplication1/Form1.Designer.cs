﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tmrMoving = new System.Windows.Forms.Timer(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(369, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 0;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox3.Location = new System.Drawing.Point(161, 94);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(59, 22);
            this.textBox3.TabIndex = 3;
            this.textBox3.Text = "ZONE1";
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.Highlight;
            this.textBox4.Location = new System.Drawing.Point(226, 94);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(58, 22);
            this.textBox4.TabIndex = 4;
            this.textBox4.Text = "ZONE2";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.Magenta;
            this.textBox5.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox5.Location = new System.Drawing.Point(290, 93);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(63, 22);
            this.textBox5.TabIndex = 5;
            this.textBox5.Text = "ZONE3";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.Red;
            this.textBox6.Location = new System.Drawing.Point(359, 93);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(69, 22);
            this.textBox6.TabIndex = 6;
            this.textBox6.Text = "ZONE4";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.textBox7.Location = new System.Drawing.Point(435, 93);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(59, 22);
            this.textBox7.TabIndex = 7;
            this.textBox7.Text = "ZONE5";
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBox8.Location = new System.Drawing.Point(499, 93);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(61, 22);
            this.textBox8.TabIndex = 8;
            this.textBox8.Text = "ZONE6";
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.textBox9.Location = new System.Drawing.Point(566, 94);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(66, 22);
            this.textBox9.TabIndex = 9;
            this.textBox9.Text = "ZONE7";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.Maroon;
            this.textBox10.Location = new System.Drawing.Point(638, 94);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(63, 22);
            this.textBox10.TabIndex = 10;
            this.textBox10.Text = "ZONE8";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox11.Location = new System.Drawing.Point(707, 94);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(65, 22);
            this.textBox11.TabIndex = 11;
            this.textBox11.Text = "ZONE9";
            this.textBox11.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.Yellow;
            this.textBox12.Location = new System.Drawing.Point(778, 94);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(63, 22);
            this.textBox12.TabIndex = 12;
            this.textBox12.Text = "ZONE10";
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.textBox13.Location = new System.Drawing.Point(847, 94);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(63, 22);
            this.textBox13.TabIndex = 13;
            this.textBox13.Text = "ZONE11";
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox14.Location = new System.Drawing.Point(916, 94);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(63, 22);
            this.textBox14.TabIndex = 14;
            this.textBox14.Text = "ZONE12";
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.Turquoise;
            this.textBox15.Location = new System.Drawing.Point(161, 318);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(59, 22);
            this.textBox15.TabIndex = 15;
            this.textBox15.Text = "ZONE13";
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.Color.Fuchsia;
            this.textBox17.ForeColor = System.Drawing.Color.Black;
            this.textBox17.Location = new System.Drawing.Point(226, 318);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(58, 22);
            this.textBox17.TabIndex = 17;
            this.textBox17.Text = "ZONE14";
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox18.Location = new System.Drawing.Point(290, 318);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(63, 22);
            this.textBox18.TabIndex = 18;
            this.textBox18.Text = "ZONE15";
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.Color.LightCyan;
            this.textBox19.Location = new System.Drawing.Point(359, 318);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(69, 22);
            this.textBox19.TabIndex = 19;
            this.textBox19.Text = "ZONE16";
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.Color.SpringGreen;
            this.textBox20.Location = new System.Drawing.Point(434, 318);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(60, 22);
            this.textBox20.TabIndex = 20;
            this.textBox20.Text = "ZONE17";
            this.textBox20.TextChanged += new System.EventHandler(this.textBox20_TextChanged);
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.Color.DeepPink;
            this.textBox21.Location = new System.Drawing.Point(502, 318);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(58, 22);
            this.textBox21.TabIndex = 21;
            this.textBox21.Text = "ZONE18";
            this.textBox21.TextChanged += new System.EventHandler(this.textBox21_TextChanged);
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.Color.Thistle;
            this.textBox22.Location = new System.Drawing.Point(566, 318);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(66, 22);
            this.textBox22.TabIndex = 22;
            this.textBox22.Text = "ZONE19";
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.Color.Yellow;
            this.textBox23.Location = new System.Drawing.Point(638, 318);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(63, 22);
            this.textBox23.TabIndex = 23;
            this.textBox23.Text = "ZONE20";
            // 
            // textBox24
            // 
            this.textBox24.BackColor = System.Drawing.Color.BurlyWood;
            this.textBox24.Location = new System.Drawing.Point(707, 318);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(65, 22);
            this.textBox24.TabIndex = 24;
            this.textBox24.Text = "ZONE21";
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.Color.DarkSalmon;
            this.textBox25.Location = new System.Drawing.Point(778, 318);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(63, 22);
            this.textBox25.TabIndex = 25;
            this.textBox25.Text = "ZONE22";
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.Color.DarkGray;
            this.textBox26.Location = new System.Drawing.Point(847, 318);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(58, 22);
            this.textBox26.TabIndex = 26;
            this.textBox26.Text = "ZONE23";
            // 
            // textBox27
            // 
            this.textBox27.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox27.Location = new System.Drawing.Point(911, 318);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(58, 22);
            this.textBox27.TabIndex = 27;
            this.textBox27.Text = "ZONE24";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1104, 410);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(28, 29);
            this.button1.TabIndex = 28;
            this.button1.Text = "↑";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1104, 470);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(28, 29);
            this.button2.TabIndex = 29;
            this.button2.Text = "↓";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1133, 439);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(28, 29);
            this.button3.TabIndex = 30;
            this.button3.Text = "→";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1070, 439);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(28, 29);
            this.button4.TabIndex = 31;
            this.button4.Text = "←";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(527, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 33;
            this.label2.Text = "LOOP 1";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(527, 276);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 17);
            this.label3.TabIndex = 34;
            this.label3.Text = "LOOP 2";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // tmrMoving
            // 
            this.tmrMoving.Enabled = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1009, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 17);
            this.label5.TabIndex = 36;
            this.label5.Text = "TL56TTESTS/ Tray Status";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1297, 559);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer tmrMoving;
        private System.Windows.Forms.Label label5;
    }
}

